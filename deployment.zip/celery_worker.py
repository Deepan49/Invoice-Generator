from app import create_celery_app

celery = create_celery_app()
